WEIGHT_MATRIX <- function(criteria, max_par, res, tf_numbers, tg_numbers, base_grn, abs_cor){

  # criteria                   <- 2 # 2 for like, 3 for AIC, 4 for BF
  OUTPUT                     <- res$OUTPUT

  x                          <- list()
  top_logics                 <- 10
  BEST_LIKELIHOODS           <- array(x,c(tg_numbers, 2*top_logics))
  BEST_LIKELIHOODS_k         <- array(x,c(tg_numbers))
  BEST_LIKELIHOODS_L         <- array(x,c(tg_numbers))
  weight_matrix              <- matrix(0, nrow = tf_numbers , ncol = tg_numbers)

  for(gene_id in 1:tg_numbers){
    top                      <- top_logics
    top_index                <- 1
    BEST_LIKELIHOODS_k_tmp   <- c()
    BEST_LIKELIHOODS_L_tmp   <- c()
    likelihood_list          <- c()

    set_numbers              <- which(res$BEST_LIKELIHOODS[gene_id,] != 1000000)
    up_limit                 <- min(length(set_numbers), max_par)
    if(up_limit > 0){
      I                      <- sort( res$BEST_LIKELIHOODS[gene_id, 1:up_limit] , decreasing = FALSE, index.return = TRUE)$ix
      M                      <- OUTPUT[[gene_id,I[1]]]
      ############################################################################
      target_variable        <- data[ ,tf_numbers+gene_id]
      predictive_data        <- data[ ,1:tf_numbers]
      TF_names               <- colnames(predictive_data)

      base_grn_tmp           <- base_grn[[colnames(data)[tf_numbers + gene_id]]]
      h_potential_tfs1       <- which(colnames(data)[1:tf_numbers] %in% base_grn_tmp)
      h_potential_tfs2       <- which(abs(cor(target_variable, predictive_data))>abs_cor)
      h_potential_tfs        <- intersect(h_potential_tfs1, h_potential_tfs2)

      if(length(h_potential_tfs)>0){
        predictive_data      <- TF_names[h_potential_tfs]
      }else{
        predictive_data      <- c()
      }
      ##########################################################################
      for(k in 1:up_limit){
        if(!is.vector(OUTPUT[[gene_id,k]])){
          likelihood_list    <- c(likelihood_list,  OUTPUT[[gene_id,k]][ ,k+2^k+criteria])  # for likelihood  or AIC or BF
        }else{
          likelihood_list    <- c(likelihood_list,  OUTPUT[[gene_id,k]][k+2^k+criteria])
        }
      } # end for k

      if((criteria==2)||(criteria==3)){
        likelihood_list      <- sort(likelihood_list, decreasing = FALSE)
      }else{
        likelihood_list      <- sort(likelihood_list, decreasing = TRUE)
      }

      top                    <- min(top, length(likelihood_list))
      likelihood_threshold   <- likelihood_list[top]
      ############################################################################
      for(k in 1:up_limit){
        if((criteria==2)|(criteria==3)){
          if(!is.vector(OUTPUT[[gene_id,k]])){
            OUTPUT_filtered  <- OUTPUT[[gene_id,k]][OUTPUT[[gene_id,k]][ ,k+2^k+criteria]<=likelihood_threshold, ]
          }else{
            OUTPUT_filtered  <- OUTPUT[[gene_id,k]][OUTPUT[[gene_id,k]][  k+2^k+criteria]<=likelihood_threshold]
          }
        }else if(criteria==4){
          if(!is.vector(OUTPUT[[gene_id,k]])){
            OUTPUT_filtered  <- OUTPUT[[gene_id,k]][OUTPUT[[gene_id,k]][ ,k+2^k+criteria]>=likelihood_threshold, ]
          }else{
            OUTPUT_filtered  <- OUTPUT[[gene_id,k]][OUTPUT[[gene_id,k]][  k+2^k+criteria]>=likelihood_threshold]
          }
        }

        if(length(OUTPUT_filtered)>0){
          if(is.vector(OUTPUT_filtered)){
            BEST_LIKELIHOODS[[gene_id, top_index]]<- OUTPUT_filtered
            BEST_LIKELIHOODS_k_tmp                <- c(BEST_LIKELIHOODS_k_tmp, k)
            BEST_LIKELIHOODS_L_tmp                <- c(BEST_LIKELIHOODS_L_tmp, OUTPUT_filtered[k+2^k+criteria])
            top_index                             <- top_index + 1
          }else{
            for(r_filtered in 1:nrow(OUTPUT_filtered)){
              BEST_LIKELIHOODS[[gene_id, top_index]]<- OUTPUT_filtered[r_filtered, ]
              BEST_LIKELIHOODS_k_tmp              <- c(BEST_LIKELIHOODS_k_tmp, k)
              BEST_LIKELIHOODS_L_tmp              <- c(BEST_LIKELIHOODS_L_tmp, OUTPUT_filtered[r_filtered, k+2^k+criteria])
              top_index                           <- top_index + 1
            }
          }
        } # if len output filtered >0
      } # k
      BEST_LIKELIHOODS_k[[gene_id]] <- BEST_LIKELIHOODS_k_tmp
      BEST_LIKELIHOODS_L[[gene_id]] <- BEST_LIKELIHOODS_L_tmp
      ############################################################################
      if((criteria==2)||(criteria==3)){
        sort_order                  <- sort(BEST_LIKELIHOODS_L[[gene_id]], decreasing = FALSE, index.return = TRUE)$ix
      }else{
        sort_order                  <- sort(BEST_LIKELIHOODS_L[[gene_id]], decreasing = TRUE , index.return = TRUE)$ix
      }

      BEST_LIKELIHOODS_L_reordered  <- BEST_LIKELIHOODS_L[[gene_id]][sort_order]
      BEST_LIKELIHOODS_k_reordered  <- BEST_LIKELIHOODS_k[[gene_id]][sort_order]

      for(reg_gene in 1:length(h_potential_tfs)){
        for(i in 1:top){
          k_tmp    <-   BEST_LIKELIHOODS_k_reordered[i]
          reg      <-   BEST_LIKELIHOODS[[gene_id, sort_order[i]]][1:k_tmp]

          if(k_tmp==1){
            top_ranked_lg           <- which(reg == reg_gene, arr.ind = TRUE)
          }else{
            top_ranked_lg           <- which(reg == reg_gene, arr.ind = TRUE)
          }

          if(length(top_ranked_lg)>0){
            bf_tmp                  <- BEST_LIKELIHOODS[[gene_id, sort_order[i]]][length(BEST_LIKELIHOODS[[gene_id, sort_order[i]]])]
            weight_matrix[h_potential_tfs[reg_gene],gene_id]<- bf_tmp
            break
          }
        }
      } # end for reg_gene
      ############################################################################
    } # end for up_limit
  } # end for gene_id

  edge_calc <- function(input_matrix){
    true_edges <- c()
    for(j in 1:ncol(input_matrix)){
      for(i in 1:nrow(input_matrix)){
        true_edges <- rbind(true_edges, c(TF_names[i], colnames(data)[tf_numbers+j],input_matrix[i,j]))
      }
    }
    true_edges <- as.data.frame(true_edges)
    return(true_edges)
  }

  Link            <- edge_calc(weight_matrix)
  colnames(Link)  <- c("from", "to", "BF_score")
  Link$BF_score   <- as.numeric(Link$BF_score)
  Link_index      <- sort(Link[ ,3], decreasing = TRUE, index.return = TRUE)$ix
  Link            <- as.data.frame(Link[Link_index, ])
  ##############################################################################
  return(Link)
}
