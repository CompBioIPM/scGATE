#' The file format conversion of the base GRNs
#'
#' This function summarizes information in the base GRN file and outputs it in array format
#'
#' @param "parquet_file" A base GRN file in "*.parquet" format.
#'
#' @return The base GRN in array format.
#' @export

read_base_GRN     <- function(parquet_file){

  pr_targets      <- unique(parquet_file$gene_short_name)
  x               <- list()
  pr_candidates   <- array(x,length(length(pr_targets)))

  for(k in 1:length(pr_targets)){
    gene_id_tmp   <- pr_targets[k]
    data_tmp      <- parquet_file[parquet_file$gene_short_name==gene_id_tmp, ]

    candidate_tf_tmp   <- c()
    for(i in 1:nrow(data_tmp)){
      data_tmp_row     <- data_tmp[i, ]
      TFs_tmp          <- data_tmp_row[which(data_tmp_row==1)]
      candidate_tf_tmp <- c(candidate_tf_tmp, colnames(TFs_tmp))
    }
    candidate_tf_tmp   <- sort(unique(candidate_tf_tmp))
    pr_candidates[[gene_id_tmp]] <- candidate_tf_tmp
  }
  return(pr_candidates)
}
