LF <- function(data = data_gene, base_GRN = NA, kh_act=kh_act_tmp, number_of_em_iterations = NA, max_num_regulators = NA, abs_cor = NA, top_rules = NA, weight_thr = NA){
  #+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  library(VGAM)
  library(truncnorm)

  # data = data_gene; base_GRN = base_grn_tmp; kh_act=kh_act_tmp; number_of_em_iterations = number_of_em_iterations; max_num_regulators = max_num_regulators; abs_cor=abs_cor
  criteria            <- 2

  base_GRN            <- as.data.frame(base_GRN)
  colnames(base_GRN)  <- c("from", "to")

  ss                  <- nrow(data)
  number_of_genes     <- length(unique(colnames(data)))
  gene_names          <- unique(colnames(data))
  ##############################################################################
  if(is.na(number_of_em_iterations)){
    number_of_em_iterations<- 10
  }
  if(is.na(max_num_regulators)){
    max_num_regulators<- min(number_of_genes-1,3)
  }
  if(is.na(abs_cor)){
    abs_cor           <- 0
  }
  if(is.na(top_rules)){
    top_rules         <- 1
  }
  if(is.na(weight_thr)){
    weight_thr        <- 0.05
  }
  ##############################################################################
  activated_val  <- function(g, gene_name_in){
    k_act_in     <- kh_act[1, gene_name_in]
    n_act_in     <- kh_act[2, gene_name_in]
    # print(k_act_in); print(n_act_in)
    out          <- ((k_act_in^n_act_in +1)*(g^n_act_in))/((k_act_in^n_act_in) + (g^n_act_in))
    return(out)
  }

  inhibited_val  <- function(g, gene_name_in){
    k_act_in     <- kh_act[1, gene_name_in]
    n_act_in     <- kh_act[2, gene_name_in]
    # print(k_act_in); print(n_act_in)
    out          <- 1-(((k_act_in^n_act_in +1)*(g^n_act_in))/((k_act_in^n_act_in) + (g^n_act_in)))
    return(out)
  }
  #+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  ToComputeLogic <- function(X, Y, ORD){
    # X = predictive_data; ORD

    if(is.vector(X)){
      SAMP            <- X
      Y               <- Y
    }else{
      SAMP            <- X[ ,c(ORD)]
      Y               <- Y[c(ORD)]
    }

    ncol_SAMP         <- length(c(ORD))

    if(length(c(ORD))>1){
      SAMP_PARTITIONED  <- matrix(rep(1,  nrow(SAMP)*(2^ncol_SAMP)), nrow(SAMP)  , 2^ncol_SAMP)
    }else{
      SAMP              <- matrix(SAMP, ncol = ncol_SAMP)
      SAMP_PARTITIONED  <- matrix(rep(1,length(SAMP)*(2^ncol_SAMP)), length(SAMP), 2^ncol_SAMP)
    }

    new_logic_index   <- 1
    for(gene_id in 1:ncol_SAMP){
      SAMP_PARTITIONED[ ,new_logic_index]  <- SAMP_PARTITIONED[ ,new_logic_index]*activated_val(SAMP[ ,gene_id], Y[gene_id])
    }

    for(k in 1:ncol_SAMP){
      # k=1; i=1
      D = combn(1:ncol_SAMP,k)  # not of elements are choosen
      for(i in 1:ncol(D)){
        index_of_not    <- t(D[,i])
        index_of_act    <- setdiff(1:ncol_SAMP, index_of_not)

        new_logic_index <- new_logic_index + 1

        for(j in 1:ncol(index_of_not)){
          SAMP[ ,index_of_not[j]]             <- inhibited_val(SAMP[ ,index_of_not[j]], Y[index_of_not[j]])
        }
        if(length(index_of_act)>0){
          for(j in 1:length(index_of_act)){
            SAMP[ ,index_of_act[j]]           <- activated_val(SAMP[ ,index_of_act[j]], Y[index_of_act[j]])
          }
        }

        for(gene_id in 1:ncol_SAMP){
          SAMP_PARTITIONED[ ,new_logic_index] <- SAMP_PARTITIONED[ ,new_logic_index]*SAMP[ ,gene_id]
        }

        if(is.vector(X)){
          SAMP            <- X
        }else{
          SAMP            <- X[ ,c(ORD)]
        }
      }
    }
    return(SAMP_PARTITIONED)
  }
  # ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  x                       <- list()
  LOGIC_VALUES            <- array(x,c(number_of_genes,max_num_regulators))
  LOGIC_VALUES_PRO        <- array(x,c(number_of_genes,max_num_regulators))

  data_v                  <- unlist(as.vector(matrix(data)))
  data_v_large            <- data_v[data_v>0]
  default_scale           <- sqrt(var(data_v_large))
  pi                      <- length(data_v[data_v==0])/length(data_v)
  #print(pi)

  for(gene_id in 1:number_of_genes){
    # gene_id=6; k=2; j=1
    impact_set_info <- base_GRN[base_GRN[ ,2]==gene_names[gene_id],  ]
    ############################################################################
    target_variable <- data[  , gene_id]
    predictive_data <- data[  ,-gene_id]

    if(!is.vector(predictive_data)){
      h_potential_tfs <- colnames(predictive_data)[ which(abs(cor(target_variable, predictive_data))>abs_cor) ]
    }else{
      h_potential_tfs <- gene_names[-gene_id][which(abs(cor(target_variable, predictive_data))>abs_cor)]
    }

    target_variable <- activated_val(target_variable, gene_names[gene_id])
    non_zero_targets<- target_variable[target_variable>0]
    if((length(non_zero_targets)>1)&( !all(non_zero_targets==non_zero_targets[1]) )){
      scale         <- max(sqrt(var(target_variable[target_variable>0])), default_scale)
    }else{
      scale         <- default_scale
    }

    if(nrow(impact_set_info)>0){
      predictive_genes<- intersect(impact_set_info$from, h_potential_tfs)
      n               <- length(predictive_genes)
      predictive_data <- data[ ,predictive_genes]
    }else{
      n               <- 0
      predictive_data <- c()
      predictive_genes<- c()
    }
    ############################################################################
    if(n>0){
      for(k in 1:min(max_num_regulators,n)){         # to the highest number of causal genes
        C             <- combn(1:n,k)         # choose causal gene index
        AGRE_OUT      <- c()
        AGRE_OUT_PRO  <- c()
        for(j in 1:ncol(C)){
          initial_omega                 <- matrix(c(rep(1/(2^k),(2^k)*number_of_em_iterations)), number_of_em_iterations, 2^k)
          iteration                     <- 1
          ORD                           <- t(C[,j])
          predictive_data_partitioned   <- ToComputeLogic(predictive_data, predictive_genes, ORD)
          target_pro                    <- matrix(c(rep(0,ss*(2^k))), ss, 2^k)

          for(target_index in 1:ss){
            for(z in 1:length(predictive_data_partitioned[target_index, ])){
              dn  <- dtruncnorm(target_variable[target_index], a = 0, b = 1, mean = predictive_data_partitioned[target_index,z], sd = scale)
              if(target_variable[target_index]==0){
                target_pro[target_index,z] <-   pi + (1-pi)*dn + 0.01
              }else{
                target_pro[target_index,z] <-        (1-pi)*dn + 0.01
              }
            }
          }

          while(iteration < number_of_em_iterations){
            initial_omega_tmp           <- initial_omega[iteration, ]
            target_pro_weighted         <- matrix(c(rep(0,ss*(2^k))), ss, 2^k)
            for(i_v in 1:(2^k)){
              target_pro_weighted[ ,i_v]<- (initial_omega_tmp[i_v])*target_pro[ ,i_v]
            }
            target_pro_weighted_row_sum <- rowSums(target_pro_weighted, na.rm = FALSE, dims = 1)
            target_pro_weighted_scaled  <- target_pro_weighted/target_pro_weighted_row_sum
            initial_omega_updated       <- colSums(target_pro_weighted_scaled, na.rm = FALSE, dims = 1)/ss
            iteration                   <- iteration +1
            initial_omega[iteration, ]  <- initial_omega_updated
          }
          target_pro_weighted           <- matrix(c(rep(0,ss*(2^k))), ss, 2^k)
          for(i_v in 1:(2^k)){
            target_pro_weighted[ ,i_v]  <- (initial_omega_updated[i_v])*target_pro[ ,i_v]
          }
          target_pro_weighted_row_sum   <- rowSums(target_pro_weighted, na.rm = FALSE, dims = 1)
          sum_log_likelihood            <- (-1)*sum(log10(target_pro_weighted_row_sum))
          BIC                           <- 2*sum_log_likelihood + (2^k)*log10(ss)
          AIC                           <- 2*sum_log_likelihood + (2^k)*2
          #################################### random case situation #######################################
          target_pro_base                  <- matrix(c(rep(0,ss*(2^k))), ss, 2^k)
          for(target_index in 1:ss){
            dn  <- dtruncnorm(target_variable[target_index], a = 0, b = 1, mean = rep(1/(2^k),(2^k)), sd = scale)
            if(target_variable[target_index]==0){
              target_pro_base[target_index, ] <- pi + (1-pi)*dn + 0.01
            }else{
              target_pro_base[target_index, ] <-      (1-pi)*dn + 0.01
            }
          }
          initial_omega                    <- c(rep(1/(2^k),(2^k)))
          for(i_v in 1:(2^k)){
            target_pro_base[ ,i_v]         <- (initial_omega[i_v])*target_pro_base[ ,i_v]
          }
          sum_log_likelihood_base          <- (-1)*sum(log10(rowSums(target_pro_base, na.rm = FALSE, dims = 1)))
          ###################################################################################################
          AGRE_OUT                     <- rbind(AGRE_OUT, c(ORD, initial_omega_updated, sum_log_likelihood_base, sum_log_likelihood, AIC))
          AGRE_OUT_PRO                 <- rbind(AGRE_OUT_PRO, c(target_pro_weighted_row_sum))
        }
        LOGIC_VALUES[[gene_id,k]]      <- AGRE_OUT
        LOGIC_VALUES_PRO[[gene_id,k]]  <- AGRE_OUT_PRO
      }
    }
    #############################################################
  }

  x               <- list()
  OUTPUT          <- array(x,c(number_of_genes,max_num_regulators))
  OUTPUT_PRO      <- array(x,c(number_of_genes,max_num_regulators))
  BEST_LIKELIHOODS<- matrix(c(rep(1000000,number_of_genes*max_num_regulators)), number_of_genes, max_num_regulators)
  BEST_BFS        <- matrix(c(rep(1000000,number_of_genes*max_num_regulators)), number_of_genes, max_num_regulators)
  for(gene_id in 1:number_of_genes){
    for(i in 1:max_num_regulators){
      # gene_id=2; i=3
      RES                          <- LOGIC_VALUES[[gene_id,i]]

      if(length(RES)>0){
        I                          <- sort(RES[,ncol(RES)], decreasing = FALSE, index.return = TRUE)$ix
        SORTED_RES                 <- RES[I,]

        if( !is.vector(SORTED_RES) ){
          BEST_LIKELIHOODS[gene_id,i]<- SORTED_RES[1,ncol(SORTED_RES)-1]   # save best likelihood value
          BF_COL                     <- SORTED_RES[                ,ncol(SORTED_RES)-2]-SORTED_RES[ ,ncol(SORTED_RES)-1] # calculate BF with    log u/v a = log u a - log v a
          SORTED_RES                 <- cbind(SORTED_RES, BF_COL)
          BEST_BFS[gene_id,i]        <- SORTED_RES[1,ncol(SORTED_RES)]
        }else{
          BEST_LIKELIHOODS[gene_id,i]<- SORTED_RES[length(SORTED_RES)-1]   # save best likelihood value
          BF_COL                     <- SORTED_RES[length(SORTED_RES)-2]-SORTED_RES[length(SORTED_RES)-1] # calculate BF with    log u/v a = log u a - log v a
          SORTED_RES                 <- c(SORTED_RES, BF_COL)
          BEST_BFS[gene_id,i]        <- SORTED_RES[length(SORTED_RES)]
        }

        OUTPUT[[gene_id,i]]        <- SORTED_RES
        OUTPUT_PRO[[gene_id,i]]    <- cbind(LOGIC_VALUES_PRO[[gene_id,i]][I, ],I)
      } # end for length(RES)
    } # end for max_reg numbers
  } # end for gene_id

  EM_SAMPLING <- function(data, gene_id, predicted_impact_set, number_of_em_iterations){
    impact_set_info <- base_GRN[base_GRN[ ,2]==gene_names[gene_id],  ]
    ############################################################################
    target_variable <- data[  , gene_id]
    predictive_data <- data[  ,-gene_id]

    if(!is.vector(predictive_data)){
      h_potential_tfs <- colnames(predictive_data)[ which(abs(cor(target_variable, predictive_data))>abs_cor) ]
    }else{
      h_potential_tfs <- gene_names[-gene_id][which(abs(cor(target_variable, predictive_data))>abs_cor)]
    }

    target_variable <- activated_val(target_variable, gene_names[gene_id])
    non_zero_targets<- target_variable[target_variable>0]
    if((length(non_zero_targets)>1)&( !all(non_zero_targets==non_zero_targets[1]) )){
      scale         <- max(sqrt(var(target_variable[target_variable>0])), default_scale)
    }else{
      scale         <- default_scale
    }

    if(nrow(impact_set_info)>0){
      predictive_genes<- intersect(impact_set_info$from, h_potential_tfs)
      n               <- length(predictive_genes)
      predictive_data <- data[ ,predictive_genes]
    }else{
      n               <- 0
      predictive_data <- c()
      predictive_genes<- c()
    }

    ss                            <- nrow(data)
    k                             <- length(predicted_impact_set)
    initial_omega                 <- round(matrix(c(rep(1/(2^k),(2^k)*number_of_em_iterations)), number_of_em_iterations, 2^k),9)
    iteration                     <- 1
    predictive_data_partitioned   <- ToComputeLogic(predictive_data, predictive_genes, predicted_impact_set)
    target_pro                    <- matrix(c(rep(0,ss*(2^k))), ss, 2^k)
    for(target_index in 1:ss){
      for(z in 1:length(predictive_data_partitioned[target_index, ])){
        dn  <- dtruncnorm(target_variable[target_index], a = 0, b = 1, mean = predictive_data_partitioned[target_index,z], sd = scale)
        if(target_variable[target_index]==0){
          target_pro[target_index,z] <-   pi + (1-pi)*dn + 0.01
        }else{
          target_pro[target_index,z] <-        (1-pi)*dn + 0.01
        }
      }
    }
    while(iteration < number_of_em_iterations){
      initial_omega_tmp           <- initial_omega[iteration, ]
      target_pro_weighted         <- matrix(c(rep(0,ss*(2^k))), ss, 2^k)
      for(i_v in 1:(2^k)){
        target_pro_weighted[ ,i_v]<- (initial_omega_tmp[i_v])*target_pro[ ,i_v]
      }
      target_pro_weighted_row_sum <- rowSums(target_pro_weighted, na.rm = FALSE, dims = 1)
      target_pro_weighted_scaled  <- target_pro_weighted/target_pro_weighted_row_sum
      initial_omega_updated       <- colSums(target_pro_weighted_scaled, na.rm = FALSE, dims = 1)/ss
      iteration                   <- iteration +1
      initial_omega[iteration, ]  <- initial_omega_updated
    }
    em_res                           <- list()
    em_res$target_pro_weighted_scaled<- target_pro_weighted_scaled
    em_res$initial_omega             <- initial_omega
    return(em_res)
  }

  W2SYMBOL <- function(logic_significance, predicted_impact_set){
    k                  <- length(predicted_impact_set)
    reg_char           <- predicted_impact_set
    x                  <- list()
    logical_sets       <- array(x,c(2^k,2))

    logical_sets_index <- 1
    logical_sets[[1,1]]<- 0
    logical_sets[[1,2]]<- paste(reg_char, collapse = '.')

    for(i in 1:k){
      not_comb <- combn(1:k,i)  # not of elements are choosen
      for(j in 1:ncol(not_comb)){
        reg_char_tmp                        <- reg_char
        logical_sets_index                  <- logical_sets_index + 1
        logical_sets[[logical_sets_index,1]]<- not_comb[ ,j]

        for(l in 1:(length(not_comb[ ,j]))){
          reg_char_tmp[not_comb[ ,j][l]]    <- paste0("~", reg_char[not_comb[ ,j][l]])
        }

        logical_sets[[logical_sets_index,2]]<- paste0(reg_char_tmp, collapse = '.')
      }
    }

    LOGIC_VECTOR       <- c()
    for(i in 1:(2^k)){
      if(logic_significance[i]==1){
        LOGIC_VECTOR   <- c(LOGIC_VECTOR, logical_sets[[i,2]])
      }
    }
    return(LOGIC_VECTOR)
  }

  predicted_gates <- c()
  for(gene_id in 1:number_of_genes){
    impact_set_info <- base_GRN[base_GRN[ ,2]==gene_names[gene_id],  ]
    ############################################################################
    target_variable <- data[  , gene_id]
    predictive_data <- data[  ,-gene_id]

    if(!is.vector(predictive_data)){
      h_potential_tfs <- colnames(predictive_data)[ which(abs(cor(target_variable, predictive_data))>abs_cor) ]
    }else{
      h_potential_tfs <- gene_names[-gene_id][which(abs(cor(target_variable, predictive_data))>abs_cor)]
    }

    if(nrow(impact_set_info)>0){
      predictive_genes<- intersect(impact_set_info$from, h_potential_tfs)
      n               <- length(predictive_genes)
      predictive_data <- data[ ,predictive_genes]
    }else{
      predictive_genes<- c()
      n               <- 0
      predictive_data <- c()
    }
    ############################################################################
    set_numbers    <- which(BEST_LIKELIHOODS[gene_id,] != 1000000)
    up_limit       <- min(length(set_numbers), max_num_regulators)

    top            <- top_rules
    top_index      <- 1
    likelihood_list<- c()
    TOP_GATES      <- array(list(),c(2*top))
    TOP_GATES_k    <- c()
    TOP_GATES_L    <- c()

    if(up_limit>0){
      for(k in 1:up_limit){
        if(!is.vector(OUTPUT[[gene_id,k]])){
          likelihood_list <- c(likelihood_list,  OUTPUT[[gene_id,k]][ ,k+2^k+criteria])  # for likelihood  or AIC or BF
        }else{
          likelihood_list <- c(likelihood_list,  OUTPUT[[gene_id,k]][k+2^k+criteria])
        }
      } # end for k
      likelihood_list     <- sort(likelihood_list, decreasing = FALSE)
      top                 <- min(top, length(likelihood_list))
      likelihood_threshold<- likelihood_list[top]
      ############################################################################
      for(k in 1:up_limit){
        if(!is.vector(OUTPUT[[gene_id,k]])){
          OUTPUT_filtered  <- OUTPUT[[gene_id,k]][OUTPUT[[gene_id,k]][ ,k+2^k+criteria]<=likelihood_threshold, ]
        }else{
          OUTPUT_filtered  <- OUTPUT[[gene_id,k]][OUTPUT[[gene_id,k]][  k+2^k+criteria]<=likelihood_threshold]
        }
        if(length(OUTPUT_filtered)>0){
          if(is.vector(OUTPUT_filtered)){
            TOP_GATES[[top_index]]  <- OUTPUT_filtered
            TOP_GATES_k    <- c(TOP_GATES_k, k)
            TOP_GATES_L    <- c(TOP_GATES_L, OUTPUT_filtered[k+2^k+criteria])
            top_index      <- top_index + 1
          }else{
            for(r_filtered in 1:nrow(OUTPUT_filtered)){
              TOP_GATES[[top_index]]<- OUTPUT_filtered[r_filtered, ]
              TOP_GATES_k  <- c(TOP_GATES_k, k)
              TOP_GATES_L  <- c(TOP_GATES_L, OUTPUT_filtered[r_filtered, k+2^k+criteria])
              top_index    <- top_index + 1
            }
          }
        } # if len output filtered >0
      } # k

      sort_order  <- sort(TOP_GATES_L, decreasing = FALSE, index.return = TRUE)$ix
      for(top_index in 1:top){
        # top_index=1
        k_tmp                <- TOP_GATES_k[ sort_order[top_index] ]
        predicted_impact_set <- TOP_GATES[[  sort_order[top_index] ]][1:k_tmp]


        BF_prediction        <- TOP_GATES[[  sort_order[top_index] ]][length(TOP_GATES[[sort_order[top_index]]])]
        likelihood_prediction<- TOP_GATES[[  sort_order[top_index] ]][length(TOP_GATES[[sort_order[top_index]]])-2]
        likelihood_base      <- TOP_GATES[[  sort_order[top_index] ]][length(TOP_GATES[[sort_order[top_index]]])-3]

        em_res               <- EM_SAMPLING(data, gene_id, predicted_impact_set, number_of_em_iterations)
        omega_estimations    <- em_res$initial_omega
        target_pro_weighted_scaled<- em_res$target_pro_weighted_scaled

        target_pro_max_posterior  <- matrix(c(rep(0,ss*(2^length(predicted_impact_set)))), ss, 2^length(predicted_impact_set))
        for(i in 1:ss){
          I_posterior             <-  sort(target_pro_weighted_scaled[i, ] , decreasing = TRUE, index.return = TRUE)$ix
          target_pro_max_posterior[i, I_posterior[1]] <- 1
        }
        target_pro_max_posterior_colsum  <- colSums(target_pro_max_posterior, na.rm = FALSE, dims = 1)
        logic_significance        <- c(rep(0,length(target_pro_max_posterior_colsum)))
        partition_min             <- weight_thr*nrow(data)
        logic_significance[which(target_pro_max_posterior_colsum> partition_min )]<- 1
        number_of_model_parameters<- sum(logic_significance)
        distributed_sample_tmp    <- round((target_pro_max_posterior_colsum[target_pro_max_posterior_colsum> partition_min])/sum(target_pro_max_posterior_colsum),2)
        predicted_impact_set      <- predictive_genes[predicted_impact_set]
        LOGIC_VECTOR              <- W2SYMBOL(logic_significance, predicted_impact_set)

        if(number_of_model_parameters>1){
          LOGIC_VECTOR       <- paste0(LOGIC_VECTOR, collapse = ' v ')
        }
        predicted_gates <- rbind(predicted_gates, c(gene_names[gene_id], c(likelihood_base, likelihood_prediction, BF_prediction, LOGIC_VECTOR, paste0(distributed_sample_tmp, collapse = ' , '))))
      } # end for top_index
      ##########################################################################
    } # end for up_limit
  } # end for gene_id
  predicted_gates            <- as.data.frame(predicted_gates)

  if(nrow(predicted_gates)>0){
    colnames(predicted_gates)  <- c("gene_name", "-log10 L0", "-log10 L1", "log10 BF", "logic_gate", "target_proportions")
    predicted_gates$`-log10 L0`<- round(as.numeric(predicted_gates$`-log10 L0`),digits=2)
    predicted_gates$`-log10 L1`<- round(as.numeric(predicted_gates$`-log10 L1`),digits=2)
    predicted_gates$`log10 BF` <- round(as.numeric(predicted_gates$`log10 BF`),digits=2)
  }

  res                  <-list()
  res$OUTPUT           <- OUTPUT
  res$BEST_LIKELIHOODS <- BEST_LIKELIHOODS
  res$BEST_BFS         <- BEST_BFS
  res$OUTPUT_PRO       <- OUTPUT_PRO
  res$LOGIC_VALUES_PRO <- LOGIC_VALUES_PRO
  res$predicted_gates_top_logics    <- predicted_gates

  return(res)
}
