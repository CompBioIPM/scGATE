#' Context-Specific TF-gene Network Inference from scRNA-seq Data
#'
#' This function reconstructs a context-specific TF-gene network from scRNA-seq data. It takes as input the gene expression profiles from a group of related cells, such as those derived from the same tissue or cell type.
#'
#' @param "data" A gene expression matrix with normalized counts within the (0,1) interval, where samples are represented as rows and genes as columns. The gene expression matrix should have been preprocessed using the scRNA_seq_preprocessing() function.
#' @param "base_GRN" Base TF-gene interactions derived from external hints (e.g., scATAC-seq data and TF binding site motifs on DNA). Leave it empty if no base GRN is available.
#' @param "h_act" Parameter of the Hill climbing function. It is the hill coefficient that represents the cooperativity or sigmoidicity of the TF regulatory response. The default value is 7.
#' @param "number_of_em_iterations" The number of iterations in the expectation-maximization (EM) algorithm. The default value is 3.
#' @param "max_num_regulators" Maximum number of TFs in a logic gate that can regulate the target gene profile. The default value is 3.
#' @param "abs_cor" This parameter varies in the (0, 1) interval and further removes edges with low absolute Pearson correlations between TFs and their targets. A (default) value of 0 indicates no filtration based on correlations.
#' @param "num_cores" Specify the number of parallel workers (adjust according to your system)
#'
#' @return The predicted TF-gene interactions (directed edges) in the context-specific network.
#' @export

scGATE_edge <- function(data = data, base_GRN = NA, h_act = NA, number_of_em_iterations = NA, max_num_regulators = NA, abs_cor = NA, num_cores = NA){

  library(VGAM)
  library(truncnorm)
  library(doParallel)
  library(foreach)
  library(doSNOW)

  #data = data; base_GRN = NA; h_act = 10; max_num_regulators = 3; number_of_em_iterations = NA; abs_cor = 0.03; num_cores = NA

  k_act         <- 0.7
  ss            <- nrow(data$n_counts)

  tf_names      <- data$tf_list
  tg_names      <- data$tg_list
  tf_numbers    <- length(tf_names)
  tg_numbers    <- length(tg_names)

  x             <- list()
  base_tf_prior <- array(x,c(length(tg_names)))
  for(i in 1:length(tg_names)){
    base_tf_prior[[i]] <- setdiff(tf_names, tg_names[i])
  }

  if(length(base_GRN)<2){
    base_GRN  <- array(x)
    for(tg_tmp in tg_names){
      base_GRN[[tg_tmp]] <- setdiff(tf_names, tg_tmp)
    }
  }
  if(is.na(h_act)){
    h_act     <- 7
  }
  if(is.na(number_of_em_iterations)){
    number_of_em_iterations<- 3
  }
  if(is.na(max_num_regulators)){
    max_num_regulators <- min(tf_numbers, 3)
  }
  if(is.na(abs_cor)){
    abs_cor   <- 0
  }
  if(is.na(num_cores)){
    num_cores <- detectCores()
  }

  n_counts       <- data$n_counts
  ##############################################################################
  activated_val  <- function(g){
    out   <-      ((k_act^h_act +1)*(g^h_act))/((k_act^h_act) + (g^h_act))
    return(out)
  }

  inhibited_val  <- function(g){
    out   <-   1-(((k_act^h_act +1)*(g^h_act))/((k_act^h_act) + (g^h_act)))
    return(out)
  }
  ##############################################################################
  ToComputeLogic <- function(X,ORD){
    # X = predictive_data
    # ORD

    if(is.vector(X)){
      SAMP            <- X
    }else{
      SAMP            <- X[ ,c(ORD)]
    }

    ncol_SAMP         <- length(c(ORD))

    if(length(c(ORD))>1){
      SAMP_PARTITIONED  <- matrix(rep(1,  nrow(SAMP)*(2^ncol_SAMP)), nrow(SAMP)  , 2^ncol_SAMP)
    }else{
      SAMP              <- matrix(SAMP, ncol = ncol_SAMP)
      SAMP_PARTITIONED  <- matrix(rep(1,length(SAMP)*(2^ncol_SAMP)), length(SAMP), 2^ncol_SAMP)
    }

    new_logic_index   <- 1
    for(gene_id in 1:ncol_SAMP){
      SAMP_PARTITIONED[ ,new_logic_index]  <- SAMP_PARTITIONED[ ,new_logic_index]*activated_val(SAMP[ ,gene_id])
    }

    for(k in 1:ncol_SAMP){
      # k=1; i=1
      D = combn(1:ncol_SAMP,k)  # not of elements are choosen
      for(i in 1:ncol(D)){
        index_of_not    <- t(D[,i])
        index_of_act    <- setdiff(1:ncol_SAMP, index_of_not)

        new_logic_index <- new_logic_index + 1

        for(j in 1:ncol(index_of_not)){
          SAMP[ ,index_of_not[j]]             <- inhibited_val(SAMP[ ,index_of_not[j]])
        }
        if(length(index_of_act)>0){
          for(j in 1:length(index_of_act)){
            SAMP[ ,index_of_act[j]]           <- activated_val(SAMP[ ,index_of_act[j]])
          }
        }

        for(gene_id in 1:ncol_SAMP){
          SAMP_PARTITIONED[ ,new_logic_index] <- SAMP_PARTITIONED[ ,new_logic_index]*SAMP[ ,gene_id]
        }

        if(is.vector(X)){
          SAMP            <- X
        }else{
          SAMP            <- X[ ,c(ORD)]
        }
      }
    }
    return(SAMP_PARTITIONED)
  }
  ##############################################################################
  x                 <- list()
  LOGIC_VALUES      <- array(x,c(tg_numbers,max_num_regulators))
  OUTPUT            <- array(x,c(tg_numbers,max_num_regulators))
  BEST_LIKELIHOODS  <- matrix(c(rep(1000000,tg_numbers*max_num_regulators)), tg_numbers, max_num_regulators)
  BEST_BFS          <- matrix(c(rep(1000000,tg_numbers*max_num_regulators)), tg_numbers, max_num_regulators)

  data_v            <- unlist(as.vector(matrix(n_counts[ ,(tf_numbers+1):ncol(n_counts)])))
  data_v_large      <- data_v[data_v>0]
  default_scale     <- sqrt(var(data_v_large))
  pi                <- length(data_v[data_v==0])/length(data_v)
  # print(pi)

  # num_cores         <- detectCores()
  cat("training process started with ", num_cores," computing cores\n")

  cl                <- makeCluster(num_cores)
  registerDoParallel(cl)

  for(gene_id in 1:tg_numbers){

    # k=2; j=1; gene_id=3
    cat("current gene: ", colnames(n_counts)[tf_numbers + gene_id]," \n")

    # Create a progress bar
    progress_percent<- 0
    pb              <- txtProgressBar(min = 0, max = 100, style = 3, width = 20)

    target_variable <- n_counts[ ,tf_numbers + gene_id]
    predictive_data <- n_counts[ ,base_tf_prior[[gene_id]]]
    h_potential_tfs1<- base_tf_prior[[gene_id]][which(abs(cor(target_variable, predictive_data))>abs_cor)] # TFs in base general positive cor

    base_grn_tmp    <- base_GRN[[colnames(n_counts)[tf_numbers + gene_id]]]
    h_potential_tfs2<- intersect(colnames(n_counts)[1:tf_numbers] , base_grn_tmp)                          # TFs in base atac

    h_potential_tfs <- intersect(h_potential_tfs1, h_potential_tfs2)

    target_variable <- activated_val(target_variable)
    non_zero_targets<- target_variable[target_variable>0]
    if((length(non_zero_targets)>1)&( !all(non_zero_targets==non_zero_targets[1]) )){
      scale         <- max(sqrt(var(target_variable[target_variable>0])), default_scale)
    }else{
      scale         <- default_scale
    }

    if(length(h_potential_tfs)>0){

      if(!is.vector(predictive_data)){
        predictive_data <- predictive_data[ ,h_potential_tfs]
      }

      n             <- length(h_potential_tfs)
      total_iterations   <- 0
      for(k in 1:min(max_num_regulators,n)){
        total_iterations <- total_iterations + ncol(combn(n,k))
      }

    }else{
      n               <- 0
      predictive_data <- c()

      total_iterations<- 0
      setTxtProgressBar(pb, 100)
    }
    ############################################################################
    current_it  <- 0
    if(n>0){
      for(k in 1:min(max_num_regulators,n)){ # to the highest number of causal genes
        C         <- combn(1:n,k)          # choose causal gene index
        AGRE_OUT  <- c()
        current_it<- current_it + ncol(C)

        results  <- foreach(j = 1:ncol(C), .combine = rbind) %dopar% {
          library(truncnorm)
          initial_omega                 <- round(matrix(c(rep(1/(2^k),(2^k)*number_of_em_iterations)), number_of_em_iterations, 2^k),9)
          iteration                     <- 1
          ORD                           <- t(C[,j])
          predictive_data_partitioned   <- ToComputeLogic(predictive_data,ORD)
          target_pro                    <- matrix(c(rep(0,ss*(2^k))), ss, 2^k)

          for(target_index in 1:ss){
            for(z in 1:length(predictive_data_partitioned[target_index, ])){
              dn  <- dtruncnorm(target_variable[target_index], a = 0, b = 1, mean = predictive_data_partitioned[target_index,z], sd = scale)
              if(target_variable[target_index]==0){
                target_pro[target_index,z] <-   pi + (1-pi)*dn + 0.01
              }else{
                target_pro[target_index,z] <-        (1-pi)*dn + 0.01
              }
            }
          }

          while(iteration < number_of_em_iterations){
            initial_omega_tmp           <- initial_omega[iteration, ]
            target_pro_weighted         <- matrix(c(rep(0,ss*(2^k))), ss, 2^k)
            for(i_v in 1:(2^k)){
              target_pro_weighted[ ,i_v]<- (initial_omega_tmp[i_v])*target_pro[ ,i_v]
            }
            target_pro_weighted_row_sum <- rowSums(target_pro_weighted, na.rm = FALSE, dims = 1)
            target_pro_weighted_scaled  <- target_pro_weighted/target_pro_weighted_row_sum
            initial_omega_updated       <- round(colSums(target_pro_weighted_scaled, na.rm = FALSE, dims = 1)/ss,9)
            iteration                   <- iteration +1
            initial_omega[iteration, ]  <- initial_omega_updated
          }
          target_pro_weighted           <- matrix(c(rep(0,ss*(2^k))), ss, 2^k)
          for(i_v in 1:(2^k)){
            target_pro_weighted[ ,i_v]  <- (initial_omega_updated[i_v])*target_pro[ ,i_v]
          }
          target_pro_weighted_row_sum   <- rowSums(target_pro_weighted, na.rm = FALSE, dims = 1)
          sum_log_likelihood            <- (-1)*sum(log10(target_pro_weighted_row_sum))
          BIC                           <- 2*sum_log_likelihood + (2^k)*log10(ss)
          AIC                           <- 2*sum_log_likelihood + (2^k)*2
          #################################### random case situation #######################################
          target_pro_base <- matrix(c(rep(0,ss*(2^k))), ss, 2^k)
          for(target_index in 1:ss){
            dn  <- dtruncnorm(target_variable[target_index], a = 0, b = 1, mean = rep(1/(2^k),(2^k)), sd = scale)
            if(target_variable[target_index]==0){
              target_pro_base[target_index, ] <- pi + (1-pi)*dn + 0.01
            }else{
              target_pro_base[target_index, ] <-      (1-pi)*dn + 0.01
            }
          }
          initial_omega <- c(rep(1/(2^k),(2^k)))
          for(i_v in 1:(2^k)){
            target_pro_base[ ,i_v]<- (initial_omega[i_v])*target_pro_base[ ,i_v]
          }
          sum_log_likelihood_base <- (-1)*sum(log10(rowSums(target_pro_base, na.rm = FALSE, dims = 1)))
          AGRE_OUT      = c(ORD, initial_omega_updated, sum_log_likelihood_base, sum_log_likelihood, AIC)
        } # end of j
        LOGIC_VALUES[[gene_id,k]]<- results

        SORTED_RES              <- LOGIC_VALUES[[gene_id,k]]

        if(length(SORTED_RES)>0){
          if( !is.vector(SORTED_RES) ){
            I                   <- sort(SORTED_RES[,ncol(SORTED_RES)], decreasing = FALSE, index.return = TRUE)$ix
            SORTED_RES          <- SORTED_RES[I,]
            BEST_LIKELIHOODS[gene_id,k]<- SORTED_RES[1,ncol(SORTED_RES)-1]   # save best likelihood value
            BF_COL              <- SORTED_RES[                ,ncol(SORTED_RES)-2]-SORTED_RES[ ,ncol(SORTED_RES)-1] # calculate BF with    log u/v a = log u a - log v a
            SORTED_RES          <- cbind(SORTED_RES, BF_COL)
            BEST_BFS[gene_id,k] <- SORTED_RES[1,ncol(SORTED_RES)]
          }else{
            BEST_LIKELIHOODS[gene_id,k]<- SORTED_RES[length(SORTED_RES)-1]   # save best likelihood value
            BF_COL              <- SORTED_RES[length(SORTED_RES)-2]-SORTED_RES[length(SORTED_RES)-1] # calculate BF with    log u/v a = log u a - log v a
            SORTED_RES          <- c(SORTED_RES, BF_COL)
            BEST_BFS[gene_id,k] <- SORTED_RES[length(SORTED_RES)]
          }
          OUTPUT[[gene_id,k]]   <- SORTED_RES
        } # end for length(RES)

        progress_percent <- round(100*current_it/total_iterations,2)
        setTxtProgressBar(pb, progress_percent)

      } # end for k
    } # end for n (ncol predictive data)

    close(pb)
  } # end for gene_id
  stopCluster(cl)
  registerDoSEQ()

  cat("preparing output ...\n")

  EM_SAMPLING <- function(n_counts, gene_id, predicted_impact_set, number_of_em_iterations){
    target_variable              <- n_counts[ ,tf_numbers + gene_id]
    predictive_data              <- n_counts[ ,base_tf_prior[[gene_id]]]
    h_potential_tfs1             <- base_tf_prior[[gene_id]][which(abs(cor(target_variable, predictive_data))>abs_cor)] # TFs in base general positive cor

    base_grn_tmp                 <- base_GRN[[colnames(n_counts)[tf_numbers + gene_id]]]
    h_potential_tfs2             <- intersect(colnames(n_counts)[1:tf_numbers] , base_grn_tmp)                          # TFs in base atac

    h_potential_tfs               <- intersect(h_potential_tfs1, h_potential_tfs2)

    if(!is.vector(predictive_data)){
      predictive_data             <- predictive_data[ ,h_potential_tfs]
    }

    target_variable               <- activated_val(target_variable)
    non_zero_targets              <- target_variable[target_variable>0]
    if((length(non_zero_targets)>1)&( !all(non_zero_targets==non_zero_targets[1]) )){
      scale                       <- max(sqrt(var(target_variable[target_variable>0])), default_scale)
    }else{
      scale                       <- default_scale
    }

    ss                            <- nrow(n_counts)
    k                             <- length(predicted_impact_set)
    initial_omega                 <- round(matrix(c(rep(1/(2^k),(2^k)*number_of_em_iterations)), number_of_em_iterations, 2^k),9)
    iteration                     <- 1
    predictive_data_partitioned   <- ToComputeLogic(predictive_data,predicted_impact_set)
    target_pro                    <- matrix(c(rep(0,ss*(2^k))), ss, 2^k)

    for(target_index in 1:ss){
      for(z in 1:length(predictive_data_partitioned[target_index, ])){
        dn  <- dtruncnorm(target_variable[target_index], a = 0, b = 1, mean = predictive_data_partitioned[target_index,z], sd = scale)
        if(target_variable[target_index]==0){
          target_pro[target_index,z] <- pi + (1-pi)*dn + 0.01
        }else{
          target_pro[target_index,z] <-      (1-pi)*dn + 0.01
        }
      }
    }
    while(iteration < number_of_em_iterations){
      initial_omega_tmp           <- initial_omega[iteration, ]
      target_pro_weighted         <- matrix(c(rep(0,ss*(2^k))), ss, 2^k)
      for(i_v in 1:(2^k)){
        target_pro_weighted[ ,i_v]<- (initial_omega_tmp[i_v])*target_pro[ ,i_v]
      }
      target_pro_weighted_row_sum <- rowSums(target_pro_weighted, na.rm = FALSE, dims = 1)
      target_pro_weighted_scaled  <- target_pro_weighted/target_pro_weighted_row_sum
      initial_omega_updated       <- round(colSums(target_pro_weighted_scaled, na.rm = FALSE, dims = 1)/ss, 9)
      iteration                   <- iteration +1
      initial_omega[iteration, ]  <- initial_omega_updated
    }
    em_res                           <- list()
    em_res$target_pro_weighted_scaled<- target_pro_weighted_scaled
    em_res$initial_omega             <- initial_omega
    return(em_res)
  }

  W2SYMBOL <- function(logic_significance, predicted_impact_set){
    k                  <- length(predicted_impact_set)
    reg_char           <- predicted_impact_set
    x                  <- list()
    logical_sets       <- array(x,c(2^k,2))

    logical_sets_index <- 1
    logical_sets[[1,1]]<- 0
    logical_sets[[1,2]]<- paste(reg_char, collapse = '.')

    for(i in 1:k){
      not_comb <- combn(1:k,i)  # not of elements are choosen
      for(j in 1:ncol(not_comb)){
        reg_char_tmp                        <- reg_char
        logical_sets_index                  <- logical_sets_index + 1
        logical_sets[[logical_sets_index,1]]<- not_comb[ ,j]

        for(l in 1:(length(not_comb[ ,j]))){
          reg_char_tmp[not_comb[ ,j][l]]    <- paste0("~", reg_char[not_comb[ ,j][l]])
        }

        logical_sets[[logical_sets_index,2]]<- paste0(reg_char_tmp, collapse = '.')
      }
    }

    LOGIC_VECTOR       <- c()
    for(i in 1:(2^k)){
      if(logic_significance[i]==1){
        LOGIC_VECTOR   <- c(LOGIC_VECTOR, logical_sets[[i,2]])
      }
    }
    return(LOGIC_VECTOR)
  }
  ##############################################################################
  BF_optimal                 <- c()
  likelihood_optimal         <- c()
  x                          <- list()
  PREDICTED_IMPACT_SET       <- array(x,c(tg_numbers))
  PREDICTED_LOGIC            <- array(x,c(tg_numbers,3))

  predicted_gates                <- c()
  a_posteriori_distributed_sample<- list()

  for(gene_id in 1:tg_numbers){
    set_numbers <- which(BEST_LIKELIHOODS[gene_id,] != 1000000)
    if(length(set_numbers)>0){
      I                        <- sort(BEST_LIKELIHOODS[gene_id,1:min(max_num_regulators,max(set_numbers))] , decreasing = FALSE, index.return = TRUE)$ix
      M                        <- OUTPUT[[gene_id,I[1]]]

      if(!is.vector(M)){
        predicted_impact_set   <- M[1,1:I[1]]
        BF_prediction          <- M[1,ncol(M)]
        likelihood_prediction  <- M[1,ncol(M)-2]
        likelihood_base        <- M[1,ncol(M)-3]
      }else{
        predicted_impact_set   <- M[1:I[1]]
        BF_prediction          <- M[length(M)]
        likelihood_prediction  <- M[length(M)-2]
        likelihood_base        <- M[length(M)-3]
      }
                                            # (n_counts, gene_id, predicted_impact_set, number_of_em_iterations)
      em_res                    <- EM_SAMPLING(n_counts, gene_id, predicted_impact_set, number_of_em_iterations)
      omega_estimations         <- em_res$initial_omega
      target_pro_weighted_scaled<- em_res$target_pro_weighted_scaled

      target_pro_max_posterior  <- matrix(c(rep(0,ss*(2^length(predicted_impact_set)))), ss, 2^length(predicted_impact_set))
      for(i in 1:ss){
        I_posterior             <-  sort(target_pro_weighted_scaled[i, ] , decreasing = TRUE, index.return = TRUE)$ix
        target_pro_max_posterior[i, I_posterior[1]] <- 1
      }
      target_pro_max_posterior_colsum     <- colSums(target_pro_max_posterior, na.rm = FALSE, dims = 1)
      logic_significance                  <- c(rep(0,length(target_pro_max_posterior_colsum)))
      partition_min                       <- 0.05*nrow(n_counts)
      logic_significance[which(target_pro_max_posterior_colsum> partition_min )]<- 1
      number_of_model_parameters          <- sum(logic_significance)
      distributed_sample_tmp              <- target_pro_max_posterior_colsum[target_pro_max_posterior_colsum>0]

      NE                        <- length(predicted_impact_set)
      BF_optimal                <- c(BF_optimal, NE*BF_prediction)
      likelihood_optimal        <- c(likelihood_optimal, NE*likelihood_prediction)

      target_variable           <- n_counts[ ,tf_numbers + gene_id]
      predictive_data           <- n_counts[ ,base_tf_prior[[gene_id]]]
      h_potential_tfs1          <- base_tf_prior[[gene_id]][which(abs(cor(target_variable, predictive_data))>abs_cor)] # TFs in base general positive cor

      base_grn_tmp              <- base_GRN[[colnames(n_counts)[tf_numbers + gene_id]]]
      h_potential_tfs2          <- intersect(colnames(n_counts)[1:tf_numbers] , base_grn_tmp)                          # TFs in base atac

      h_potential_tfs           <- intersect(h_potential_tfs1, h_potential_tfs2)


      if(length(predicted_impact_set)>1){
        predictive_data         <- predictive_data[ ,h_potential_tfs]
        predictive_data         <- predictive_data[ ,predicted_impact_set]
        predicted_impact_set    <- colnames(predictive_data)
      }else if(length(h_potential_tfs)>1){ # length(predicted_impact_set) ==1
        predictive_data         <- predictive_data[ ,h_potential_tfs]
        predicted_impact_set    <- colnames(predictive_data)[predicted_impact_set]
      }else if(!is.vector(predictive_data)){
        predicted_impact_set    <- h_potential_tfs
      }else{
        predicted_impact_set    <- base_tf_prior[[gene_id]]
      }

      PREDICTED_IMPACT_SET[[gene_id]]<- predicted_impact_set
      LOGIC_VECTOR              <- W2SYMBOL(logic_significance, predicted_impact_set)

      if(length(predicted_impact_set)>0){
        PREDICTED_LOGIC[[gene_id, 1]]  <- predicted_impact_set
        PREDICTED_LOGIC[[gene_id, 2]]  <- logic_significance
        PREDICTED_LOGIC[[gene_id, 3]]  <- LOGIC_VECTOR
      }

      if(number_of_model_parameters>1){
        LOGIC_VECTOR            <- paste0(LOGIC_VECTOR, collapse = ' v ')
      }
      predicted_gates                           <- rbind(predicted_gates, c(colnames(n_counts)[tf_numbers + gene_id], c(likelihood_base, likelihood_prediction, BF_prediction, LOGIC_VECTOR)))
      a_posteriori_distributed_sample[[gene_id]]<- distributed_sample_tmp
    } # end for set numbers
  } # end for gene_id

  predicted_gates            <- as.data.frame(predicted_gates)

  if(nrow(predicted_gates)>0){
    colnames(predicted_gates)  <- c("gene_name", "-log10 L0", "-log10 L1", "log10 BF", "logic_gate")
    predicted_gates$`-log10 L0`<- round(as.numeric(predicted_gates$`-log10 L0`),digits=2)
    predicted_gates$`-log10 L1`<- round(as.numeric(predicted_gates$`-log10 L1`),digits=2)
    predicted_gates$`log10 BF` <- round(as.numeric(predicted_gates$`log10 BF`),digits=2)
  }

  PREDICTED_IMPACT_SET[[gene_id+1]]   <- c(-1,-1)

  res                  <-list()
  res$OUTPUT           <- OUTPUT
  res$PREDICTED_LOGIC  <- PREDICTED_LOGIC
  res$BF_LIKELIHOOD    <- as.data.frame(cbind(BF_optimal, likelihood_optimal))
  res$BEST_LIKELIHOODS <- BEST_LIKELIHOODS
  res$BEST_BFS         <- BEST_BFS

  res$predicted_gates_top_logics    <- predicted_gates
  res$a_posteriori_distributed_sample <- a_posteriori_distributed_sample

  ranked_edge_list      <- WEIGHT_MATRIX(criteria = 2, n_counts = n_counts, base_GRN, base_tf_prior, max_num_regulators = max_num_regulators, res, tf_names = tf_names, tg_names = tg_names, abs_cor)
  res$ranked_edge_list  <- ranked_edge_list
  rownames(ranked_edge_list) <- NULL

  cat("JOB DONE!\n")

  return(ranked_edge_list)
}
