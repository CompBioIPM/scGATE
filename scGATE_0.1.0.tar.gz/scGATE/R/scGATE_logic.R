#' Inference of TF-gene Networks with Logic Gates
#'
#' This function combines structure inference with logic gates to model gene regulatory networks with unknown structure. It takes as input the gene expression profiles from a group of related cells, such as those derived from the same tissue or cell type.
#'
#' @param  "data"         A gene expression matrix with normalized counts within the (0,1) interval, where samples are represented as rows and genes as columns. The gene expression matrix should have been preprocessed using the scRNA_seq_preprocessing() function.
#' @param  "base_GRN"     Base TF-gene interaction network derived from external hints (e.g., scATAC-seq data and TF binding site motifs on DNA). Leave it empty if no base GRN is available.
#' @param  "h_set"        The range of possible values for the "h" parameter in the Hill climbing function.
#' @param  "number_of_em_iterations"  The number of iterations in the expectation-maximization (EM) algorithm. The default value is 3.
#' @param  "max_num_regulators" Maximum number of TFs in a logic gate that can regulate the target gene profile. The default value is 3.
#' @param  "abs_cor"      This parameter varies in the (0, 1) interval and further removes edges with low absolute Pearson correlations between TFs and their targets. A (default) value of 0 indicates no filtration based on correlations.
#' @param  "top_gates"    The number of top Boolean logic gates to be reported for each target gene, based on Bayes Factor. The default value is 1.
#' @param  "run_mode"     Use "simple" for a faster algorithm run and "complex" for more precise results that take more time. The argument is relevant to the possible complexities in the hill function parameter space for regulatory TFs and target genes. The default value is "simple".
#' @param  "weight_threshold"  The output form scGATE will present the logic combination or partition that yields a certain percentage of the target gene, specifically when it is above the weight_threshold. The default value is 0.05.
#' @param  "num_cores"   Specify the number of parallel workers (adjust according to your system)
#'
#' @return The predicted logic gates.
#' @export

scGATE_logic <- function(data = data, base_GRN = NA, h_set = NA, number_of_em_iterations = NA, max_num_regulators = NA, abs_cor = NA, top_gates = NA, run_mode = NA, weight_threshold = NA, num_cores = NA){

  library(doParallel)
  library(foreach)
  library(doSNOW)

  #data = data; top_gates = 10; run_mode = "complex"; base_GRN = NA; h_set = h_set; number_of_em_iterations = 10; max_num_regulators = 2; abs_cor = NA; num_cores = NA; weight_threshold = 0.05

  tf_list    <- intersect(data$tf_list, colnames(data$n_counts))
  tg_list    <- intersect(data$tg_list, colnames(data$n_counts))

  if(any(is.na(base_GRN))&(!length(tf_list)>0)){
    # define base_GRN
    gene_list <- unique(colnames(data$n_counts))
    base_GRN  <- c()
    for(i in gene_list){
      for(j in gene_list){
        if(i!=j){
          base_GRN  <- rbind(base_GRN, c(i, j))
        }
      }
    }
  }else if(any(is.na(base_GRN))&(length(tf_list)>0)){
    # define base_GRN
    base_GRN  <- c()
    for(i in tf_list){
      for(j in tg_list){
        if(i!=j){
          base_GRN  <- rbind(base_GRN, c(i, j))
        }
      }
    }
  }else if(!any(is.na(base_GRN))){
    if(is.vector(base_GRN)){
      base_GRN<- matrix(base_GRN, ncol = 2)
    }
    base_GRN  <- base_GRN[((base_GRN[, 1] %in% colnames(data$n_counts) & base_GRN[, 2] %in% colnames(data$n_counts))&(base_GRN[,1] != base_GRN[,2])), ]
  }

  if(is.vector(base_GRN)){
    base_GRN  <- matrix(base_GRN, ncol = 2)
  }

  suppressWarnings({
    if(is.na(h_set)){
      h_set     <- c(1, 1.25, 1.75, 2.5, 5, 7)
    }
  })

  if(is.na(number_of_em_iterations)){
    number_of_em_iterations<- 3
  }

  if(is.na(max_num_regulators)){
    max_num_regulators<- min(length(unique(colnames(data$n_counts)))-1,3)
  }
  if(is.na(abs_cor)){
    abs_cor   <- 0
  }
  if(is.na(top_gates)){
    top_gates <- 1
  }
  if(is.na(run_mode)){
    run_mode  <- "simple"
  }
  if(is.na(weight_threshold)){
    weight_threshold<- 0.05
  }
  if(is.na(num_cores)){
    num_cores <- detectCores()
  }
  ##############################################################################
  # num_cores         <- detectCores()
  cat("training process started with ", num_cores," computing cores\n")

  cl                <- makeCluster(num_cores)
  registerDoParallel(cl)

  all_res           <- list()
  for(target_gene in unique(base_GRN[ ,2])){
    # target_gene="2979"; i=3

    print(paste0("Current gene: ", target_gene))

    base_grn_tmp    <- base_GRN[base_GRN[ ,2]==target_gene, ]

    if(is.vector(base_grn_tmp)){
      base_grn_tmp  <- as.data.frame(t(base_grn_tmp))
    }

    gene_names_tmp  <- unique(unlist(c(base_grn_tmp[base_grn_tmp[ ,2]==target_gene, ])))
    gene_numbers    <- length(gene_names_tmp)

    if(gene_numbers >1){
      data_gene       <- data$n_counts[  ,gene_names_tmp]

      # Set Hill climbing function parameter space
      if(run_mode == "simple"){
        k_set         <- t(as.data.frame(rep(0.7, gene_numbers)))
        repeated      <- rep(h_set, each = gene_numbers)
        combinations  <- matrix(repeated, nrow = length(h_set), ncol = gene_numbers, byrow = TRUE)
      }else if(run_mode == "complex"){
        k_set         <- t(as.data.frame(rep(0.7, gene_numbers)))
        if(gene_numbers<10){
          repeated_vector<- replicate(gene_numbers, h_set, simplify = FALSE)
          combinations<- as.data.frame(do.call(expand.grid, repeated_vector))
        }else{
          combinations<- data.frame(matrix(nrow = 1000, ncol = gene_numbers))
          for (i in 1:gene_numbers) {
            combinations[, i] <- sample(h_set, 1000, replace = TRUE)
          }
        }
      }

      colnames(k_set) <- gene_names_tmp
      colnames(combinations) <- gene_names_tmp
      kh_set          <- rbind(k_set, combinations)

      results  <- foreach(i = 2:nrow(kh_set), .combine = rbind) %dopar% {
        kh_act_tmp    <- kh_set[c(1,i), ]
                                #  (data = data_gene, base_GRN = NA          , kh_act=kh_act_tmp, number_of_em_iterations = NA                     , max_num_regulators = NA                , abs_cor = NA     , top_rules = NA, weight_thr = NA)
        res           <- scGATE::LF(data = data_gene, base_GRN = base_grn_tmp, kh_act=kh_act_tmp, number_of_em_iterations = number_of_em_iterations, max_num_regulators = max_num_regulators, abs_cor = abs_cor, top_rules = 1 , weight_thr = weight_threshold)
        if(length(res$predicted_gates_top_logics)>0){
          output      <- as.data.frame( c(res$predicted_gates_top_logics, kh_set[i, ]) )
        }else{
          output      <- c()
        }
        output
      }

      colnames(results)  <- c("gene_name", "-log10 L0", "-log10 L1", "log10 BF", "logic_gate", "target_proportions")
      results            <- as.data.frame(results)
      results$gene_name  <- as.character(results$gene_name)
      results$`log10 BF` <- as.numeric(results$`log10 BF`)
      results$`-log10 L1`<- as.numeric(results$`-log10 L1`)
      sorted_bf_index <- sort(results$`log10 BF`, decreasing = TRUE, index.return = TRUE)$ix
      results         <- results[sorted_bf_index, ]

      all_res[[target_gene]] <- results[1:min(top_gates, nrow(results)), ]

    } # end for gene_numbers
  } # end for target_gene
  stopCluster(cl)
  registerDoSEQ()

  cat("preparing output ...\n")

  # export result as dataframe
  gates   <-  c()
  for(tg_id in tg_list){
    gates <- rbind(gates, all_res[[tg_id]][ ,1:6]) #
  }
  rownames(gates) <- NULL

  # Create an empty matrix to store unique rows
  unique_rows <- matrix(nrow = 0, ncol = ncol(gates))

  # Keep track of unique combinations of gene_name and logic_gate
  unique_combinations <- c()

  # Iterate through each row of the matrix
  for (i in 1:nrow(gates)) {
    gene_name <- gates[i, "gene_name"]
    logic_gate <- gates[i, "logic_gate"]
    combination <- paste(gene_name, logic_gate, sep = "_")

    # Check if the current combination is unique
    if (!(combination %in% unique_combinations)) {
      unique_combinations <- c(unique_combinations, combination)
      unique_rows <- rbind(unique_rows, gates[i, ])
    }
  }

  cat("JOB DONE!\n")
  return(unique_rows)
}
