#' Inference of TF-gene Networks with Logic Gates
#'
#' This function combines structure inference with logic gates to model gene regulatory networks with unknown structure. It takes as input the gene expression profiles from a group of related cells, such as those derived from the same tissue or cell type.

#' @param  "data"         A gene expression matrix with samples as rows and genes as columns. Gene names must be provided in the columns. The gene expression values should be in normalized counts within the (0,1) interval.
#' @param  "number_of_em_iterations"  Number of EM iterations.
#' @param  "max_num_regulators" Maximum number of TFs in a logic gate that can regulate the target gene profile.
#' @param  "h_set"        The range of possible values for the "h" parameter in the Hill climbing function.
#' @param  "base_grn"     Base TF-gene interactions derived from external hints (e.g., scATAC-seq data and TF binding site motifs on DNA).
#' @param  "abs_cor"      Threshold for the absolute correlation values. TF-gene interactions with an absolute Pearson correlation lower than this threshold will be filtered out from the analysis. The default value is 0.
#' @param  "top_gates"    The number of top logic gates to be reported for each target gene, based on Bayes Factor.
#' @param  "grid_par"     The possible complexities in the hill function parameter space for regulatory TFs and target genes. Use "simple" for a faster algorithm run and "complex" for more precise results that take more time.

#' @return  The predicted logic gates.
#' @export

scGATE_logic <- function(data = data, number_of_em_iterations = NA, max_num_regulators = NA, h_set = NA, base_grn = NA, abs_cor = NA, top_gates = NA, grid_par = NA){
  ##############################################################################
  if(is.na(number_of_em_iterations)){
    number_of_em_iterations<- 10
  }
  if(is.na(max_num_regulators)){
    max_num_regulators<- min(number_of_genes-1,3)
  }
  if(is.na(abs_cor)){
    abs_cor           <- 0
  }
  if(is.na(top_gates)){
    top_gates         <- 1
  }
  if(is.na(grid_par)){
    grid_par          <- "simple"
  }
  ##############################################################################
  all_res     <- list()
  for(target_gene in unique(base_grn[ ,2])){
    base_grn_tmp    <- base_grn[base_grn[ ,2]==target_gene, ]

    if(is.vector(base_grn_tmp)){
      base_grn_tmp  <- as.data.frame(t(base_grn_tmp))
    }

    gene_names_tmp  <- unlist(unique(c(base_grn_tmp[base_grn_tmp[ ,2]==target_gene, ])))
    gene_numbers    <- length(gene_names_tmp)

    if(gene_numbers >1){
      data_gene       <- data[  ,gene_names_tmp]

      # Set Hill climbing function parameter space
      if(grid_par == "simple"){
        k_set         <- t(as.data.frame(rep(0.7, gene_numbers)))
        repeated      <- rep(h_set, each = gene_numbers)
        combinations  <- matrix(repeated, nrow = length(h_set), ncol = gene_numbers, byrow = TRUE)
      }else if(grid_par == "complex"){
        k_set         <- t(as.data.frame(rep(0.7, gene_numbers)))
        repeated_vector<- replicate(gene_numbers, h_set, simplify = FALSE)
        combinations  <- as.data.frame(do.call(expand.grid, repeated_vector))
      }

      colnames(k_set) <- gene_names_tmp
      colnames(combinations) <- gene_names_tmp
      kh_set          <- rbind(k_set, combinations)

      x               <- list()
      scGATE_res_tmp  <- array(x,nrow(kh_set))
      counter         <- 2

      for(i in 2:nrow(kh_set)){
        kh_act_tmp    <- kh_set[c(1,i), ]
        res           <- LF(data = data_gene, number_of_em_iterations = number_of_em_iterations, max_num_regulators = max_num_regulators, kh_act=kh_act_tmp, base_grn_tmp, abs_cor=abs_cor)

        scGATE_res_tmp[[counter]] <- res
        counter                <- counter + 1
      }

      res_tmp         <- c()
      for(counter in 2:nrow(kh_set)){
        if(length(scGATE_res_tmp[[counter]]$predicted_gates_top_logics)>0){
          res_tmp     <- rbind(res_tmp , c(scGATE_res_tmp[[counter]]$predicted_gates_top_logics, kh_set[counter, ]))
        }
      }

      res_tmp         <- as.data.frame(res_tmp)
      res_tmp$gene_name <- as.character(res_tmp$gene_name)
      res_tmp$`log10 BF`<- as.numeric(res_tmp$`log10 BF`)
      sorted_bf_index <- sort(res_tmp$`log10 BF`, decreasing = TRUE, index.return = TRUE)$ix
      res_tmp         <- res_tmp[sorted_bf_index, ]

      all_res[[target_gene]] <- res_tmp[1:min(top_gates, nrow(res_tmp)), ]

    } # end for gene_numbers
  } # end for target_gene
  return(all_res)
}
