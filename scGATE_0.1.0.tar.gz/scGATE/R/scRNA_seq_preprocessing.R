#' Preprocess scRNA-seq data
#'
#' This function preprocesses scRNA-seq data by performing various steps such as normalization, and rescaling.
#'
#' @param data The scRNA-seq data matrix with cells in rows and genes in columns.
#' @param library_size_normalization A flag indicating whether library size normalization should be performed. Default is "True".
#' @param tf_list A list of transcription factors (TFs) to consider. Default is NA.
#'
#' @return The preprocessed scRNA-seq data.
#'
#' @examples
#' data_scRNA_seq    <- read.csv("scRNA_seq_data.csv")
#' preprocessed_data <- scRNA_seq_preprocessing(data = data_scRNA_seq, library_size_normalization = "True", tf_list = c("TF1", "TF2"))
#'
scRNA_seq_preprocessing <- function(data = data_scRNA_seq, library_size_normalization, tf_list = NA) {

  # Check if data is in matrix format
  if (!is.matrix(data)) {
    data <- as.matrix(data)
  }

  # Remove columns with zero variance and display a message for each removed gene
  removed_genes <- colnames(data)[apply(data, 2, var) == 0]
  data <- data[, apply(data, 2, var) != 0]

  # Display a message for each removed gene
  for (gene in removed_genes) {
    message(paste("Gene", gene, "has been removed due to zero variance."))
  }

  suppressWarnings({
    if(is.na(tf_list)){
      tf_list<- colnames(data)
    }else{
      tf_list<- intersect(tf_list, colnames(data))
    }
  })

  tg_list  <- colnames(data)
  data     <- na.omit(data)

  if(library_size_normalization=="True"){
    # remove cells with low read counts
    data   <- data[apply(data > 0, 1, sum) > 0.1*ncol(data), ]
    # library size normalization
    data   <- t(apply(data, 1, function(x) x/sum(x)))*100
  }

  # Rescale normalized counts into the (0,1) interval
  q975     <- quantile(as.numeric(unlist(data)), probs = 0.975 , na.rm = FALSE)
  data     <- data/q975
  data     <- replace(data, data>=1, 0.9999)

  # sort expression profile matrix with tfs in the first columns and targets in the next columns
  data     <- data[ ,c(tf_list, tg_list)]

  normalized_counts         <- list()
  normalized_counts$tf_list <- tf_list
  normalized_counts$tg_list <- tg_list
  normalized_counts$n_counts<- data
  return(normalized_counts)
}
